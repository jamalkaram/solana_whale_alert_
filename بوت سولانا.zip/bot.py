
import requests

def track_whales():
    print("Tracking whales on Solana...")
    # هنا سيكون كود تتبع المحافظ

if __name__ == "__main__":
    track_whales()
