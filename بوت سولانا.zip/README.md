# Solana Whale Alert Bot

This bot alerts you when a whale creates a new Solana token.